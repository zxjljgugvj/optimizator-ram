@echo off

timeout /t 1 /nobreak >nul

sc config wuauserv start= disabled >nul 2>&1

timeout /t 1 /nobreak >nul

sc config UsoSvc start= disabled >nul 2>&1

timeout /t 1 /nobreak >nul

sc config bits start= disabled >nul 2>&1

timeout /t 1 /nobreak >nul

reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU" /v NoAutoUpdate /t REG_DWORD /d 1 /f >nul

timeout /t 1 /nobreak >nul

reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU" /v AUOptions /t REG_DWORD /d 1 /f >nul

timeout /t 1 /nobreak >nul

reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\PushNotifications" /v ToastEnabled /t REG_DWORD /d 0 /f >nul

echo.

:loop

:: === seeing ram ===
powershell -command "Get-CimInstance Win32_OperatingSystem | ForEach-Object { Write-Output (' {0:N2} GB / Total: {1:N2} GB' -f (($_.TotalVisibleMemorySize - $_.FreePhysicalMemory)/1MB), ($_.TotalVisibleMemorySize/1MB)) }"

timeout /t 1 /nobreak >nul

:: === clear темп ===
del /q /f /s %TEMP%\* >nul 2>&1
del /q /f /s C:\Windows\Temp\* >nul 2>&1

timeout /t 1 /nobreak >nul

:: === I don't know what I did ===
ipconfig /flushdns >nul

timeout /t 1 /nobreak >nul

:: === clar ram ===
powershell -command "Get-Process | Where-Object { $_.Id -ne $PID } | ForEach-Object { try { $_.MinWorkingSet = $_.MinWorkingSet } catch {} }"

timeout /t 1 /nobreak >nul

:: Run RamMap silently with the -Et -Es -Em -Ew flag to clear everything
"%~dp0NOT_DELETE\RAMMap64.exe" -Et -Es -Em -Ew

timeout /t 1 /nobreak >nul

:: === clar ram ===
powershell -command "Get-Process | Where-Object { $_.Id -ne $PID } | ForEach-Object { try { $_.MinWorkingSet = $_.MinWorkingSet } catch {} }"

timeout /t 1 /nobreak >nul

:: Run RamMap silently with the -Et -Es -Em -Ew flag to clear everything
"%~dp0NOT_DELETE\RAMMap64.exe" -Et -Es -Em -Ew

timeout /t 1 /nobreak >nul

:: === clar ram ===
powershell -command "Get-Process | Where-Object { $_.Id -ne $PID } | ForEach-Object { try { $_.MinWorkingSet = $_.MinWorkingSet } catch {} }"

timeout /t 1 /nobreak >nul

:: Run RamMap silently with the -Et -Es -Em -Ew flag to clear everything
"%~dp0NOT_DELETE\RAMMap64.exe" -Et -Es -Em -Ew

timeout /t 1 /nobreak >nul

:: === clar ram ===
powershell -command "Get-Process | Where-Object { $_.Id -ne $PID } | ForEach-Object { try { $_.MinWorkingSet = $_.MinWorkingSet } catch {} }"

timeout /t 1 /nobreak >nul

:: Run RamMap silently with the -Et -Es -Em -Ew flag to clear everything
"%~dp0NOT_DELETE\RAMMap64.exe" -Et -Es -Em -Ew

timeout /t 1 /nobreak >nul

:: === clar ram ===
powershell -command "Get-Process | Where-Object { $_.Id -ne $PID } | ForEach-Object { try { $_.MinWorkingSet = $_.MinWorkingSet } catch {} }"

timeout /t 1 /nobreak >nul

:: Run RamMap silently with the -Et -Es -Em -Ew flag to clear everything
"%~dp0NOT_DELETE\RAMMap64.exe" -Et -Es -Em -Ew

timeout /t 5 /nobreak >nul

goto loop